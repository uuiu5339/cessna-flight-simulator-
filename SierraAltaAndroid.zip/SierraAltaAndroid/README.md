# Sierra Alta Flight — Android

Landscape-first Android app for the 3D flight simulator. It runs in a hardware-accelerated Android WebView, uses immersive full-screen mode, keeps the screen on during flight, and includes LootLocker guest accounts and online landing milestones. The game retains its Spanish, English, and Brazilian Portuguese options, city and aircraft selectors, and touch controls.

## Build and install

1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this `SierraAltaAndroid` folder in Android Studio and let Gradle sync.
3. Connect an Android phone with USB debugging enabled, then choose **Run**; or use **Build → Build APK(s)** to create a sideloadable APK.

Package: `com.sierraalta.flight` · minimum Android: 8.0 (API 26) · launch orientation: landscape.

## Connect LootLocker

The Android build uses LootLocker’s REST API directly from the game. It creates a guest player and stores the guest identifier on the device. The Game Key is a client-side key; never put an Admin API key or other server secret in the app.

1. Create a game in the [LootLocker Web Console](https://console.lootlocker.com/) and enable **Guest Login** in Game Settings → Platforms.
2. In the game settings, create a progression with the key `successful_landings`. Set tier thresholds for the landing milestones you want; the app adds one point whenever the player lands safely.
3. Copy the LootLocker **Game Key** into `app/src/main/assets/lootlocker-config.js`, replacing `PASTE_YOUR_LOOTLOCKER_GAME_KEY_HERE`. Keep `gameVersion` numeric semver format.
4. Build and install the app. The welcome screen connects a guest account; **View achievements** shows the player's current landing progression.

Guest accounts are stored on the device. Clearing app storage or reinstalling can lose access to a guest profile. Add an account-linking/sign-in method before promising cross-device recovery. Online achievements need internet; the flight sim itself still shows its no-internet screen when required online assets cannot load.

LootLocker documents REST guest login and progression updates at [Guest Login](https://docs.lootlocker.com/players/authentication/how-to/guest-login/) and [Player Progressions](https://docs.lootlocker.com/game-systems/progressions/how-to/player/).

## Network requirement

The app bundles the game UI, maps, aircraft models, and sound generation. Three.js is fetched from jsDelivr, so the 3D simulator and LootLocker achievements need an internet connection unless the rendering library is already cached. The service worker caches the app shell for repeat launches.

## Browser install

The PWA copy can be hosted on HTTPS. Configure its `lootlocker-config.js` too, then open it in Android Chrome and choose **Install app** or **Add to Home screen**. The manifest requests landscape/full-screen presentation; browser and device policy can affect orientation.
