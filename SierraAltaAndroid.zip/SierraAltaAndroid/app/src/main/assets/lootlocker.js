(function () {
  const cfg = window.SIERRA_LOOTLOCKER || {};
  const api = 'https://api.lootlocker.io';
  const identifierKey = 'sierraLootLockerPlayerIdentifier';
  let token = '';
  let playerId = '';
  let busy = false;
  const configured = () => !!cfg.gameKey && !cfg.gameKey.includes('PASTE_');
  const labels = () => {
    const lang = (window.flightLanguage || 'es').toLowerCase();
    return lang.startsWith('en')
      ? { connected: 'LootLocker guest connected', offline: 'Connect to the internet to use online achievements.', setup: 'Add your LootLocker Game Key in lootlocker-config.js.', fail: 'LootLocker connection failed. Try again.', loading: 'Connecting to LootLocker…', achievements: 'Achievements', empty: 'No landing milestones unlocked yet.', failedLoad: 'Could not load achievements.' }
      : lang.startsWith('pt')
        ? { connected: 'Conta visitante LootLocker conectada', offline: 'Conecte-se à internet para usar conquistas online.', setup: 'Adicione sua Game Key do LootLocker em lootlocker-config.js.', fail: 'Falha ao conectar ao LootLocker. Tente novamente.', loading: 'Conectando ao LootLocker…', achievements: 'Conquistas', empty: 'Nenhum marco de pouso desbloqueado ainda.', failedLoad: 'Não foi possível carregar as conquistas.' }
        : { connected: 'Cuenta de invitado LootLocker conectada', offline: 'Conéctate a internet para usar los logros en línea.', setup: 'Añade tu Game Key de LootLocker en lootlocker-config.js.', fail: 'No se pudo conectar con LootLocker. Inténtalo de nuevo.', loading: 'Conectando con LootLocker…', achievements: 'Logros', empty: 'Aún no has desbloqueado hitos de aterrizaje.', failedLoad: 'No se pudieron cargar los logros.' };
  };
  const statusEl = () => document.querySelector('#lootLockerStatus');
  function status(message) { const el = statusEl(); if (el) el.textContent = message; }
  async function request(path, options = {}) {
    const response = await fetch(api + path, { ...options, headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { 'x-session-token': token } : {}), ...(options.headers || {}) } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || `LootLocker ${response.status}`);
    return data;
  }
  async function connect() {
    if (busy) return false;
    if (!configured()) { status(labels().setup); return false; }
    if (!navigator.onLine) { status(labels().offline); return false; }
    busy = true; status(labels().loading);
    try {
      let identifier = window.safeGameStorage?.get(identifierKey) || '';
      const payload = { game_key: cfg.gameKey, game_version: cfg.gameVersion || '1.0.0' };
      if (identifier) payload.player_identifier = identifier;
      let session = await request('/game/v2/session/guest', { method: 'POST', body: JSON.stringify(payload) });
      if (!session.session_token && identifier) {
        window.safeGameStorage?.set(identifierKey, '');
        session = await request('/game/v2/session/guest', { method: 'POST', body: JSON.stringify({ game_key: cfg.gameKey, game_version: cfg.gameVersion || '1.0.0' }) });
      }
      token = session.session_token || '';
      playerId = String(session.player_id || session.public_uid || '');
      if (session.player_identifier) window.safeGameStorage?.set(identifierKey, session.player_identifier);
      if (!token) throw new Error('Missing session token');
      status(`${labels().connected}${playerId ? ` · ${playerId}` : ''}`);
      return true;
    } catch (error) { console.warn('LootLocker session error', error); status(labels().fail); return false; }
    finally { busy = false; }
  }
  async function awardLanding() {
    if (!configured()) return;
    if (!token && !(await connect())) return;
    const key = cfg.landingProgressionKey || 'successful_landings';
    try {
      await request(`/game/player/progressions/${encodeURIComponent(key)}/points/add`, { method: 'POST', body: JSON.stringify({ amount: 1 }) });
      status(labels().connected);
    } catch (error) { console.warn('LootLocker landing award error', error); status(labels().fail); }
  }
  async function showAchievements() {
    if (!configured()) { status(labels().setup); return; }
    if (!token && !(await connect())) return;
    try {
      const data = await request('/game/player/progressions?count=100');
      const p = (data.items || []).find(item => item.progression_key === (cfg.landingProgressionKey || 'successful_landings'));
      status(p ? `${labels().achievements}: ${p.step} · ${p.points}` : labels().empty);
    } catch (error) { console.warn('LootLocker achievements error', error); status(labels().failedLoad); }
  }
  window.SierraLootLocker = { connect, awardLanding, showAchievements };
  document.addEventListener('DOMContentLoaded', () => {
    const panel = document.querySelector('#lootLockerPanel');
    if (!panel) return;
    panel.hidden = false;
    document.querySelector('#lootLockerConnect')?.addEventListener('click', connect);
    document.querySelector('#lootLockerAchievements')?.addEventListener('click', showAchievements);
    if (configured()) connect(); else status(labels().setup);
  });
})();
