// Public game configuration only. Never put an Admin API key or server secret here.
window.SIERRA_LOOTLOCKER = {
  gameKey: 'PASTE_YOUR_LOOTLOCKER_GAME_KEY_HERE',
  gameVersion: '1.0.0',
  landingProgressionKey: 'successful_landings'
};
